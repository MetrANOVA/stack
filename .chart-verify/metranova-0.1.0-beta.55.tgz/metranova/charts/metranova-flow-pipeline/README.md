# MetrANOVA Flow Pipeline Helm Chart

This Helm chart deploys the MetrANOVA Flow Pipeline on a Kubernetes cluster.

## Prerequisites

- Kubernetes 1.19+
- Helm 3.2.0+
- PV provisioner support in the underlying infrastructure (if using persistent volumes)

## Components

This chart deploys six main components:

1. **data-flow**: Processes NetFlow/IPFIX data from Kafka and writes to ClickHouse
2. **metadata-caida-org-as**: Manages AS and Organization metadata from CAIDA
3. **metadata-file-export**: Exports metadata from configuration files to ClickHouse
4. **metadata-ip-geo**: Manages IP geolocation metadata from MaxMind GeoLite2
5. **metadata-scireg**: Manages Science Registry metadata from external sources
6. **cache-ip-trie**: Maintains IP prefix trie cache in files to be loaded by flow pipeline.

## Installing the Chart

### From Helm Repository (Recommended)

First, add the MetrANOVA Helm repository:

```bash
helm repo add metranova https://metranova.github.io/stack
helm repo update
```

#### Install Latest Stable Release

```bash
helm install metranova-flow metranova/metranova-flow-pipeline
```

#### Install with Custom Values

```bash
helm install metranova-flow metranova/metranova-flow-pipeline -f custom-values.yaml
```

#### Install Pre-Release Version

To install a pre-release version (e.g., beta releases from version branches), use the `--devel` flag:

```bash
# Install latest pre-release version
helm install metranova-flow metranova/metranova-flow-pipeline --devel

# Install specific pre-release version
helm install metranova-flow metranova/metranova-flow-pipeline --version 0.1.0-beta --devel
```

#### Install with Inline Values

```bash
helm install metranova-flow metranova/metranova-flow-pipeline \
  --set config.clickhouse.password=mypassword \
  --set config.kafka.ssl.keyPassword=mykafkapassword
```

### From Local Source

If you're developing or want to install from local source:

```bash
# Copy example values file
cp helm/values.yaml.example helm/values.yaml

# Install from local directory
helm install metranova-flow ./helm
```

## Configuration

The following table lists the configurable parameters of the chart and their default values.

### Global Settings

| Parameter | Description | Default |
|-----------|-------------|---------|
| `image.repository` | Container image repository | `ghcr.io/metranova/pipeline` |
| `image.tag` | Container image tag | `latest` |
| `image.pullPolicy` | Image pull policy | `IfNotPresent` |
| `global.imagePullSecrets` | Image pull secrets | `[]` |
| `global.storageClassName` | Default storage class fallback for PVCs | `""` |

### Service Configuration

| Parameter | Description | Default |
|-----------|-------------|---------|
| `dataFlow.enabled` | Enable data flow service | `true` |
| `dataFlow.replicaCount` | Number of replicas for data flow | `1` |
| `metadataCaidaOrgAs.enabled` | Enable CAIDA metadata service | `true` |
| `metadataFileExport.enabled` | Enable file export metadata service | `true` |
| `metadataIpGeo.enabled` | Enable IP geo metadata service | `true` |
| `metadataScireg.enabled` | Enable SciReg metadata service | `true` |
| `cacheIpTrie.enabled` | Enable IP trie cache service | `true` |

### Base Configuration

| Parameter | Description | Default |
|-----------|-------------|---------|
| `config.debug` | Enable debug logging | `false` |
| `config.kafka.bootstrapServers` | Kafka bootstrap servers | `kafka:9092` |
| `config.kafka.consumerGroup` | Kafka consumer group | `metranova_pipeline` |
| `config.kafka.ssl.keyPassword` | Kafka SSL key password | `CHANGEME` |
| `config.clickhouse.host` | ClickHouse host | `clickhouse` |
| `config.clickhouse.port` | ClickHouse port | `9440` |
| `config.clickhouse.database` | ClickHouse database | `metranova` |
| `config.clickhouse.username` | ClickHouse username | `pipeline_user` |
| `config.clickhouse.password` | ClickHouse password | `CHANGEME` |
| `config.clickhouse.clusterName` | ClickHouse cluster name (optional) | `""` |
| `config.clickhouse.replication` | Enable ClickHouse replication | `"true"` |
| `config.clickhouse.replicaPath` | ClickHouse replica path template | `"/clickhouse/tables/{shard}/{database}/{table}"` |
| `config.clickhouse.replicaName` | ClickHouse replica name template | `"{replica}"` |

### Storage

| Parameter | Description | Default |
|-----------|-------------|---------|
| `caches.existingPvc` | Use existing PVC for caches | `""` |
| `caches.storageSize` | Storage size for caches PVC | `5Gi` |
| `caches.storageClassName` | Storage class for caches PVC | `""` |

### Certificates

| Parameter | Description | Default |
|-----------|-------------|---------|
| `certificates.existingSecret` | Use existing secret for Kafka TLS certificates | `pipeline-user` |
| `certificates.kafkaCASubPath` | Key name in secret for CA certificate | `ca.crt` |
| `certificates.kafkaCertSubPath` | Key name in secret for client certificate | `user.crt` |
| `certificates.kafkaKeySubPath` | Key name in secret for client key | `user.key` |
| `certificates.kafka.ca` | Kafka CA certificate (base64) | `""` |
| `certificates.kafka.cert` | Kafka client certificate (base64) | `""` |
| `certificates.kafka.key` | Kafka client key (base64) | `""` |

## Usage Examples

### Using Existing Secrets and ConfigMaps

```yaml
# values-production.yaml
certificates:
  existingSecret: my-kafka-certs

configFiles:
  existingConfigMap: my-pipeline-config

caches:
  existingPvc: my-cache-pvc

config:
  clickhouse:
    password: changeme_secure_password
  kafka:
    ssl:
      keyPassword: changeme_secure_kafka_password
```

```bash
helm install metranova-flow ./helm -f values-production.yaml
```

### Scaling Replicas

```bash
helm upgrade metranova-flow ./helm \
  --set dataFlow.replicaCount=3
```

### Disabling Optional Services

```bash
helm install metranova-flow ./helm \
  --set metadataScireg.enabled=false \
  --set cacheIpTrie.enabled=false
```

## Uninstalling the Chart

```bash
helm uninstall metranova-flow
```

This removes all the Kubernetes components associated with the chart and deletes the release.

## Notes

- Make sure to update the `CHANGEME` passwords in production deployments
- The chart uses a ReadWriteOnce PVC for caches because the cache writer serves shared data over HTTP to the other flow components
- Certificate files should be provided either through an existing secret or inline in values
- Configuration files (meta_*.yml) should be provided through ConfigMap
